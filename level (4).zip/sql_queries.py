import sqlite3


#Question #1. How many artists are represented in the database? 


#Question #2. How many women (Female) are in the database?


#Question #3. How many people in the database were born before 1900?


#Question #4*. What is the name of the oldest artist?

